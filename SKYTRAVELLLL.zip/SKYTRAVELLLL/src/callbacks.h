#include <gtk/gtk.h>
#include "admin_login_fonction.h"


void
on_new1_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_open1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_save1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_save_as1_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_quit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_cut1_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_copy1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_paste1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_delete1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_about1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);



void
on_login_acceuil_button_clicked        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_sign_up_acceuil_button_clicked      (GtkButton       *objet,
                                        gpointer         user_data);

void
on_client_auth_button_clicked          (GtkButton       *objet,
                                        gpointer         user_data);

void
on_admin_auth_button_clicked           (GtkButton       *objet,
                                        gpointer         user_data);

void
on_client_sign_up2_button_clicked      (GtkButton       *objet,
                                        gpointer         user_data);

void
on_client_login2_button_clicked        (GtkButton       *objet,
                                        gpointer         user_data);


void
on_retour_ges_clients_button_clicked   (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_ges_agents_admin_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data);


void
on_retour_auth_button_clicked          (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_client_login_button_clicked  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_cilent_sign_up_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_agents_esp_admin_button_clicked     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_client_esp_admin_button_clicked     (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_acceuil_esp_admin_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_admin_login_button_clicked   (GtkButton       *objet,
                                        gpointer         user_data);

void
on_login_admin_button_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_error_admin_login_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_client_sign_in_button_clicked       (GtkButton       *objet,
                                        gpointer         user_data);

void
on_retour_client_loginn_button_clicked (GtkButton       *objet,
                                        gpointer         user_data);

void
on_client_sign_up_button_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_add_client_admin_ges_clients_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewagent_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_closeconfirmation_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_closecontrolsaisie_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_agent_login_button_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_login_agent_admin_button_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_closedialogauth_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_agent_auth_button_clicked           (GtkButton       *objet,
                                        gpointer         user_data);
