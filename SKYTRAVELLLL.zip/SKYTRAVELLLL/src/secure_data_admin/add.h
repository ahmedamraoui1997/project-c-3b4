#ifdef ADD_H_
#define ADD_H_

void add_user(char user_name[], char password[], char file_name[]);

#endif
