#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <stdbool.h>
#include "admin_login_fonction.h"
#define ADMIN_ACCOUNT "ADMIN_ACCOUNT.bin"
#define CLIENT_ACCOUNT "CLIENT_ACCOUNT_CREAT.bin"
#define AGENT_ACCOUNT "agent.bin"


void
on_new1_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_open1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_save1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_save_as1_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_quit1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_cut1_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_copy1_activate                      (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_paste1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_delete1_activate                    (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}


void
on_about1_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data)
{

}




void
on_login_acceuil_button_clicked        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *skytravel ,*authentication_panel;
skytravel = lookup_widget(objet, "skytravel");
gtk_widget_hide(skytravel);
authentication_panel = create_authentication_panel();
gtk_widget_show(authentication_panel);

}


void
on_sign_up_acceuil_button_clicked      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *skytravel ,*client_sign_up;
skytravel = lookup_widget(objet, "skytravel");
gtk_widget_hide(skytravel);
client_sign_up = create_client_sign_up();
gtk_widget_show(client_sign_up);



}


void
on_client_auth_button_clicked          (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentication_panel ,*client_login;
authentication_panel = lookup_widget(objet, "authentication_panel");
gtk_widget_hide(authentication_panel);
client_login = create_client_login();
gtk_widget_show(client_login);

}


void
on_admin_auth_button_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentication_panel ,*admin_login_window;
authentication_panel = lookup_widget(objet, "authentication_panel");
gtk_widget_hide(authentication_panel);
admin_login_window = create_admin_login_window();
gtk_widget_show(admin_login_window);

}


void
on_client_sign_up2_button_clicked      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *client_login ,*client_sign_up;
client_login = lookup_widget(objet, "client_login");
gtk_widget_hide(client_login);
client_sign_up = create_client_sign_up();
gtk_widget_show(client_sign_up);


}


void
on_client_login2_button_clicked        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *client_login ,*client_sign_up;
client_sign_up = lookup_widget(objet, "client_sign_up");
gtk_widget_hide(client_sign_up);
client_login = create_client_login();
gtk_widget_show(client_login);


}




void
on_retour_ges_clients_button_clicked   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *clients_admin_window ,*espace_administrateur_window;
clients_admin_window = lookup_widget(objet, "clients_admin_window");
gtk_widget_hide(clients_admin_window);
espace_administrateur_window = create_espace_administrateur_window();
gtk_widget_show(espace_administrateur_window);
}


void
on_retour_ges_agents_admin_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *agents_admin_window ,*espace_administrateur_window;
agents_admin_window = lookup_widget(objet, "agents_admin_window");
gtk_widget_hide(agents_admin_window);
espace_administrateur_window = create_espace_administrateur_window();
gtk_widget_show(espace_administrateur_window);
}




void
on_retour_auth_button_clicked          (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentication_panel ,*skytravel;
authentication_panel = lookup_widget(objet, "authentication_panel");
gtk_widget_hide(authentication_panel);
skytravel = create_skytravel();
gtk_widget_show_all(skytravel);
}


void
on_retour_client_login_button_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *client_login ,*authentication_panel;
client_login = lookup_widget(objet, "client_login");
gtk_widget_hide(client_login);
authentication_panel = create_authentication_panel();
gtk_widget_show(authentication_panel);
}


void
on_retour_cilent_sign_up_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *client_sign_up ,*skytravel;
client_sign_up = lookup_widget(objet, "client_sign_up");
gtk_widget_hide(client_sign_up);
skytravel = create_skytravel();
gtk_widget_show(skytravel);
}


//void
//on_agents_esp_admin_button_clicked     (GtkButton       *objet,
//                                        gpointer         user_data)
//{
//GtkWidget *espace_administrateur_window ,*window1;
//espace_administrateur_window = lookup_widget(objet, "espace_administrateur_window");
//gtk_widget_hide(espace_administrateur_window);
//window1 = create_window1();
//gtk_widget_show(window1);
//}


void
on_client_esp_admin_button_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace_administrateur_window ,*clients_admin_window, *liste;
espace_administrateur_window = lookup_widget(objet, "espace_administrateur_window");
gtk_widget_hide(espace_administrateur_window);
clients_admin_window = create_clients_admin_window();
gtk_widget_show(clients_admin_window);
liste = lookup_widget(clients_admin_window,"tree_client_view");
afficher_agent_admin(liste,CLIENT_ACCOUNT);
}


void
on_retour_acceuil_esp_admin_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace_administrateur_window ,*skytravel;
espace_administrateur_window = lookup_widget(objet, "espace_administrateur_window");
gtk_widget_hide(espace_administrateur_window);
skytravel = create_skytravel();
gtk_widget_show(skytravel);
}


void
on_retour_admin_login_button_clicked   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *admin_login_window ,*authentication_panel;
admin_login_window = lookup_widget(objet, "admin_login_window");
gtk_widget_hide(admin_login_window);
authentication_panel = create_authentication_panel();
gtk_widget_show(authentication_panel);
}


void
on_login_admin_button_clicked          (GtkWidget	*objet,
                                        gpointer         user_data)
{
GtkWidget *input_user;
GtkWidget *input_password;
GtkWidget *admin_login_window ,*espace_administrateur_window, *ERROR_ADMIN_LOGIN;
char login[20]; 
char password[20];

input_user = lookup_widget(objet, "identadmin");
input_password = lookup_widget(objet, "mdpadmin");
strcpy(login, gtk_entry_get_text(GTK_ENTRY(input_user)));
strcpy(password, gtk_entry_get_text(GTK_ENTRY(input_password)));
if ((verif_login(login,password, ADMIN_ACCOUNT)) == true){
	admin_login_window = lookup_widget(objet, "admin_login_window");
	gtk_widget_hide(admin_login_window);
	espace_administrateur_window = create_espace_administrateur_window();
	gtk_widget_show(espace_administrateur_window);
	
}
else{
	admin_login_window = lookup_widget(objet, "admin_login_window");
	gtk_widget_hide(admin_login_window);
	ERROR_ADMIN_LOGIN = create_ERROR_ADMIN_LOGIN();
	gtk_widget_show(ERROR_ADMIN_LOGIN);
	
}
}


void
on_retour_error_admin_login_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *admin_login_window ,*ERROR_ADMIN_LOGIN;
ERROR_ADMIN_LOGIN = lookup_widget(objet, "ERROR_ADMIN_LOGIN");
gtk_widget_hide(ERROR_ADMIN_LOGIN);
admin_login_window = create_admin_login_window();
gtk_widget_show(admin_login_window);
}


void
on_client_sign_in_button_clicked       (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input_user;
GtkWidget *input_password;
GtkWidget *client_login ,*skytravel_WELCOME, *ERROR_CLIENT_LOGIN;
char login[20]; 
char password[20];

input_user = lookup_widget(objet, "identclient");
input_password = lookup_widget(objet, "mdpclient");
strcpy(login, gtk_entry_get_text(GTK_ENTRY(input_user)));
strcpy(password, gtk_entry_get_text(GTK_ENTRY(input_password)));
if ((verif_login_client(login, password, CLIENT_ACCOUNT)) == true){
	client_login = lookup_widget(objet, "client_login");
	gtk_widget_destroy(client_login);
	skytravel_WELCOME = create_skytravel_WELCOME();
	gtk_widget_show(skytravel_WELCOME);
	
}
else{
	client_login = lookup_widget(objet, "client_login");
	gtk_widget_destroy(client_login);
	ERROR_CLIENT_LOGIN = create_ERROR_CLIENT_LOGIN();
	gtk_widget_show(ERROR_CLIENT_LOGIN);
	
}
}


void
on_retour_client_loginn_button_clicked (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *client_login ,*ERROR_CLIENT_LOGIN;
ERROR_CLIENT_LOGIN = lookup_widget(objet, "ERROR_CLIENT_LOGIN");
gtk_widget_hide(ERROR_CLIENT_LOGIN);
client_login = create_client_login();
gtk_widget_show(client_login);
}

void
on_client_sign_up_button_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input_nom;
GtkWidget *input_prenom;
GtkWidget *input_CIN;
GtkWidget *input_tel;
GtkWidget *input_email;
GtkWidget *input_password;
GtkWidget *input_confirm_password;
GtkWidget *client_sign_up ,*skytravel_WELCOME, *ERROR_CLIENT_LOGIN;
char nom[50]; 
char prenom[50];
char CIN_entre[50];
char tel[50];
char email[50];
char password[20];
char confirm_password[20];


input_nom = lookup_widget(objet, "nomCentry");
input_prenom = lookup_widget(objet, "prenomCentry");
input_CIN = lookup_widget(objet, "CINCentry");
input_tel = lookup_widget(objet, "telCentry");
input_email = lookup_widget(objet, "emailCentry");
input_password = lookup_widget(objet, "mdpCentry");
input_confirm_password = lookup_widget(objet, "conmdpCentry");

strcpy(nom, gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(prenom, gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(CIN_entre, gtk_entry_get_text(GTK_ENTRY(input_CIN)));
strcpy(tel, gtk_entry_get_text(GTK_ENTRY(input_tel)));
strcpy(email, gtk_entry_get_text(GTK_ENTRY(input_email)));
strcpy(password, gtk_entry_get_text(GTK_ENTRY(input_password)));
strcpy(confirm_password, gtk_entry_get_text(GTK_ENTRY(input_confirm_password)));

add_client(nom, prenom, CIN_entre, tel, email, password, confirm_password, CLIENT_ACCOUNT);
client_sign_up = lookup_widget(objet, "client_sign_up");
gtk_widget_hide(client_sign_up);
skytravel_WELCOME = create_skytravel_WELCOME();
gtk_widget_show(skytravel_WELCOME);
	
}
void
on_add_client_admin_ges_clients_button_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *clients_admin_window ,*client_sign_up;
        clients_admin_window = lookup_widget(objet, "clients_admin_window");
        gtk_widget_hide(clients_admin_window);
        client_sign_up = create_client_sign_up();
        gtk_widget_show(client_sign_up);

}





/*



void
on_agent_auth_button_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
        GtkWidget *authentication_panel ,*loginadminagent;
        authentication_panel = lookup_widget(objet, "authentication_panel");
        gtk_widget_hide(authentication_panel);
        loginadminagent = create_loginadminagent();
        gtk_widget_show(loginadminagent);

}

typedef struct Agent{
char nom[20];
char prenom[20];
char cin[20];
char mail[50];
char tel[20];
char sexe[20];
date date_naissance;
date date_recrutement;
char mdp[20];
char tache[50];
}agent;

typedef struct Date{
int jour;
int mois;
int annee;
}date;



void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
        agent x;
        
        GtkWidget *window1;
        GtkWidget *afficher_agent;
        GtkWidget *treeviewagent;
        window1=lookup_widget(GTK_WIDGET(button),("window1"));
        gtk_widget_destroy(window1);
        afficher_agent=lookup_widget(GTK_WIDGET(button),("afficher_agent"));
        afficher_agent=create_afficher_agent();
        gtk_widget_show(afficher_agent);
        treeviewagent=lookup_widget(afficher_agent,"treeviewagent");
        Afficher_agent(treeviewagent,x);


}


void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

gtk_main_quit() ; 
}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
agent x;
GtkWidget *nom=lookup_widget(GTK_WIDGET(button),"nom");
GtkWidget *prenom=lookup_widget(GTK_WIDGET(button),"prenom");
GtkWidget *cin=lookup_widget(GTK_WIDGET(button),"cin");
GtkWidget *mail=lookup_widget(GTK_WIDGET(button),"mail");
GtkWidget *tel=lookup_widget(GTK_WIDGET(button),"tel");
GtkWidget *jrn=lookup_widget(GTK_WIDGET(button),"jrn");
GtkWidget *msn=lookup_widget(GTK_WIDGET(button),"msn");
GtkWidget *ann=lookup_widget(GTK_WIDGET(button),"ann");
GtkWidget *jrr=lookup_widget(GTK_WIDGET(button),"jrr");
GtkWidget *msr=lookup_widget(GTK_WIDGET(button),"msr");
GtkWidget *anr=lookup_widget(GTK_WIDGET(button),"anr");
GtkWidget *mdp=lookup_widget(GTK_WIDGET(button),"mdp");
GtkWidget *mdp2=lookup_widget(GTK_WIDGET(button),"mdp2");
GtkWidget *tache=lookup_widget(GTK_WIDGET(button),"tache");
GtkWidget *sexe=lookup_widget(GTK_WIDGET(button),"sexe");
if((strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prenom))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(cin))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mail))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(tel))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(nom))),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(tache)),"")==0))
{ 
g_print("non");
GtkWidget *dialog4;
dialog4=create_dialog4() ;
gtk_widget_show(dialog4) ;

}
else if (strcmp((gtk_entry_get_text(GTK_ENTRY(mdp))),(gtk_entry_get_text(GTK_ENTRY(mdp2)))) != 0)
{ 
g_print("non");
GtkWidget *dialog5;
dialog5=create_dialog5() ;
gtk_widget_show(dialog5) ;
}

else{
strcpy(x.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(x.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(x.cin,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(x.mail,gtk_entry_get_text(GTK_ENTRY(mail)));
strcpy(x.tel,gtk_entry_get_text(GTK_ENTRY(tel)));

strcpy(x.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(sexe)));
x.date_naissance.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrn));
x.date_naissance.mois= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(msn));
x.date_naissance.annee= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ann));
x.date_recrutement.jour= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrr));
x.date_recrutement.mois= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(msr));
x.date_recrutement.annee= (int)gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(anr));
strcpy(x.mdp,gtk_entry_get_text(GTK_ENTRY(mdp)));

strcpy(x.tache,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tache)));

GtkWidget *dialog3;
dialog3=create_dialog3() ;
gtk_widget_show(dialog3) ;

Ajouter_agent(&x);}
}


void
on_treeviewagent_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data0;
gchar *str_data1;
gchar *str_data2;
gchar *str_data3;
gchar *str_data4;
gchar *str_data5;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data0, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data1, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data2, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data3, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data4, -1);
 gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data5, -1);
  }
strcpy(x.nom,str_data0);
strcpy(x.prenom,str_data1);
strcpy(x.cin,str_data2);
strcpy(x.mail,str_data3);
strcpy(x.tel,str_data4);
strcpy(x.mdp,str_data5);

}


void
on_closeconfirmation_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *dialog3=lookup_widget(GTK_WIDGET(button),("dialog3"));

gtk_widget_destroy(dialog3);

}


void
on_closecontrolsaisie_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *dialog4=lookup_widget(GTK_WIDGET(button),("dialog4"));

gtk_widget_destroy(dialog4);

}


void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *dialog5=lookup_widget(GTK_WIDGET(button),("dialog5"));

gtk_widget_destroy(dialog5);


}


void
on_retour_agent_login_button_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *loginadminagent=lookup_widget(GTK_WIDGET(button),("loginadminagent"));

gtk_widget_destroy(loginadminagent);

}


void
on_login_agent_admin_button_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
        GtkWidget *loginadminagent ,*skytravel_WELCOME , *dialogauth;
        char login[20]; 
        char password[20];

        GtkWidget *authmail=lookup_widget(GTK_WIDGET(button),"authmail");
        GtkWidget *authmdp=lookup_widget(GTK_WIDGET(button),"authmdp");
        strcpy(login, gtk_entry_get_text(GTK_ENTRY(authmail)));
        strcpy(password, gtk_entry_get_text(GTK_ENTRY(authmdp)));
        if ((verif_login_agent(login, password, AGENT_ACCOUNT)) == true){
                loginadminagent = lookup_widget(objet, "loginadminagent");
                gtk_widget_destroy(loginadminagent);
                skytravel_WELCOME = create_skytravel_WELCOME();
                gtk_widget_show(skytravel_WELCOME);
                
        }
        else{
                loginadminagent = lookup_widget(objet, "loginadminagent");
                gtk_widget_destroy(loginadminagent);
                dialogauth = create_dialogauth();
                gtk_widget_show(dialogauth);
                
        } 
}



void
on_closedialogauth_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{GtkWidget *dialogauth=lookup_widget(GTK_WIDGET(button),("dialogauth"));

gtk_widget_destroy(dialogauth);

}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_user((char *)x.prenom);
//Na3mlo Actualiser lil liste 
GtkWidget *afficher_agent=lookup_widget(GTK_WIDGET(button),"afficher_agent");
GtkWidget *treeviewagent;

treeviewagent=lookup_widget(afficher_agent,"treeviewagent");
Afficher_agent(treeviewagent,x);
gtk_widget_show(treeviewagent);

}


*/




