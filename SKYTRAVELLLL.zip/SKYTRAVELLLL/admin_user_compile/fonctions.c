#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void ajouter(char login[], char password[]){
	FILE *f;
	f =fopen("users.txt","a+"); //ouvrir le fichier "users.txt"
	if (f != NULL){
		fprintf(f,"%s %s\n", login, password);
		fclose(f); //fermer le fichier "users.txt"
	}	
}

int verifier (char login[], char password[]){
	int exist = -1;
	FILE*id;
	char user[20];
	char password_user[20];
	id = fopen("users.txt", "r"); //ouvrir le fichier "users.txt"
	while(fscanf(id,"%s %s", user , password_user)!= EOF){
		if (( user == login) && (password_user == password)){
		exist = 0;
		}
	}
		
	fclose(id);
	return (exist);
	

}

