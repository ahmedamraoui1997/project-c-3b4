#ifndef VOL_H_
#define VOL_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_vol
{
int jour;
int mois;
int annee;
}date;

typedef struct
{ 
date aller;
date retour;
char depart[20];
char arrivee[20];
int duree;
char classe[20];
char prix[20];
//char test[1024];
char nb[20];
}vol;
void ajouter_resv (vol *v);
void ajouter (vol *v); 
void afficher (GtkWidget *liste,vol v);
void dell_user(char *depart);
void dell_user_res(char *depart);
void afficher_resv (GtkWidget *liste,vol v, char dt_aller[], char dt_retour[]);
#endif
