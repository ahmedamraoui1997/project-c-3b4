#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "fonctions.h"



int main(){
	char admin_user[20], admin_password[20];

	printf("donner admin user name :\n ");
	
	fgets(admin_user, 20 , stdin);
	printf("saisir password :\n ");
	
	fgets(admin_password,20, stdin);
	ajouter(admin_user, admin_password);
	printf("account has been added");
	return(0);
}
