#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

struct admin_preference{
    char *username[20];
    char *password[20];
};




void add_user(char user_name[], char password[], char file_name[]){
    FILE *f;
    f = fopen(file_name, "ab+");
    int i;
    struct admin_preference admin;
    if (f == NULL){
        fprintf(stderr, "ERROR: can not open file: USERS.bin");
    }
    strcpy (admin.username, user_name);
    strcpy (admin.password, password);
    for (i=0; i<1; i++ ){
        fwrite(&admin, sizeof(struct admin_preference), 1, f);
    }
    fclose(f);
}
