<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Icones Commentaire, images message png et ico (page 4)</title>
<META NAME="description" CONTENT="Icones Commentaire. Images commentaire pour mettre en avant le fait que vos visiteurs peuvent laisser un message au format png et ico. (page 4)">
<META NAME="keywords" CONTENT="Icone, Icones, Site web, Commentaire, favicon, images, png, ico">
<META NAME="robots" CONTENT="All">
<link rel="shortcut icon" href="/interface/favicon.ico">
<link rel="stylesheet" type="text/css" href="/interface/style.css">
<link rel="stylesheet" type="text/css" href="/interface/fonctions.css">
<script type="text/javascript" src="/interface/fonctions.js"></script>
<script type="text/javascript" src="/interface/jquery.js"></script>
<link href='https://fonts.googleapis.com/css?family=Titillium+Web:700,600italic,600,400italic,400' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<script type="text/javascript">
 var header_menu = new Array();
 var header_menu_hover = new Array();
 header_menu[1] = '/interface/menu-1-off.png';
 header_menu_hover[1] = '/interface/menu-1-on.png';
 header_menu[2] = '/interface/menu-2-off.png';
 header_menu_hover[2] = '/interface/menu-2-on.png';
 header_menu[3] = '/interface/menu-3-off.png';
 header_menu_hover[3] = '/interface/menu-3-on.png';
 defmenu=1;
</script>
<script type="text/javascript">
function preloadScript()
{
 img_preload('/interface/menu-1.png','/interface/menu-1-on.png','/interface/menu-1-off.png','/interface/menu-2.png','/interface/menu-2-on.png','/interface/menu-2-off.png','/interface/menu-3.png','/interface/menu-3-on.png','/interface/menu-3-off.png','/interface/icone-1-hover.png','/interface/icone-2-hover.png');
}
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52364966-3', 'auto');
  ga('send', 'pageview');

</script>
</head>

<body>

<div class="header">
  <div class="barremenu">
    <div class="logo"><a href="https://www.icone-png.com"><img src="/interface/logo-icone-png.png" alt="icone png" ></a> </div>
    <div class="menu">
      <ul>
        <li><a href="https://www.icone-png.com" >ACCUEIL ICONES</a></li>
        <li><a href="https://www.icone-png.com/search.php" class="on">RECHERCHER UNE ICONE</a></li>
      </ul>
    </div>
    <div class="compteur">
 <script language="javascript" src="https://cnt.hiwit.org/index.php?idsite=12699&zone=f"></SCRIPT><NOSCRIPT><a href=https://cnt.hiwit.org target=blank>Compteur-Live</a></NOSCRIPT>
    </div>
  </div>
  <div class="description">
    <div class="description-contenu">
      <div class="description-img"> <img  border="0" src="/interface/description.png"></div>
      <div class="description-txt">
        <h1>Icones Commentaire, images message png et ico (page 4)</h1>
        <p>Icones Commentaire. Images message ou commentaire notamment pour un livre d'or, forum ou blog. Des <strong>icones commentaires</strong> &agrave; placer &agrave; la suite d'un article afin d'indiquer &agrave; vos visiteurs qu'ils peuvent d&eacute;poser un commentaire sur votre site internet. (page 4)</p>
      </div>
    <div class="description-pg">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- icone-png-banniere -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-4576435841048824"
     data-ad-slot="7881019843"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
   </div>
    </div>
 </div>
</div>

<div class="contenu-central-onglet">
<div class="contenu-central-onglet-cat"> 

<a href="#" onclick="aff_detail('contenuonglet', 3, 1, 1, -1, 'fade');img_swaplst('headermenu',3,1,header_menu,header_menu_hover);defmenu=1;" onmouseover="img_swaplst('headermenu',3,1,header_menu,header_menu_hover)" onmouseout="img_swaplst('headermenu',3,defmenu,header_menu,header_menu_hover)"><img id="headermenu1" src="/interface/menu-1-on.png"></a>
<a href="#" onclick="aff_detail('contenuonglet', 3, 2, 1, -1, 'fade');img_swaplst('headermenu',3,2,header_menu,header_menu_hover);defmenu=2;" onmouseover="img_swaplst('headermenu',3,2,header_menu,header_menu_hover)" onmouseout="img_swaplst('headermenu',3,defmenu,header_menu,header_menu_hover)"><img id="headermenu2" src="/interface/menu-2-off.png"></a>
<a href="#" onclick="aff_detail('contenuonglet', 3, 3, 1, -1, 'fade');img_swaplst('headermenu',3,3,header_menu,header_menu_hover);defmenu=3;" onmouseover="img_swaplst('headermenu',3,3,header_menu,header_menu_hover)" onmouseout="img_swaplst('headermenu',3,defmenu,header_menu,header_menu_hover)"><img id="headermenu3" src="/interface/menu-3-off.png"></a>

</div>
</div>

<div class="contenu-onglet-fond"> 
  
  <!--premiere div -->
  <div class="contenu-onglet" id="contenuonglet1">
    <div class="contenu-onglet-cat">

	<div class="menu-ariane"><p>Vous êtes ici: <a href="https://www.icone-png.com"><strong>Icones</strong></a> > <a href="https://www.icone-png.com/site-web"><strong>Site web</strong></a> > <span>Commentaire</span></p></div>

	
<ul><li><a href="https://www.icone-png.com/site-web/accolade"> Icones Accolade <span>(19)</span></a></li><li><a href="https://www.icone-png.com/site-web/accueil"> Icones Accueil <span>(361)</span></a></li><li><a href="https://www.icone-png.com/site-web/alignement"> Icones Alignement <span>(274)</span></a></li><li><a href="https://www.icone-png.com/site-web/annuler"> Icones Annuler <span>(46)</span></a></li><li><a href="https://www.icone-png.com/site-web/attendre"> Icones Attendre <span>(5)</span></a></li><li><a href="https://www.icone-png.com/site-web/bank"> Icones Bank <span>(30)</span></a></li><li><a href="https://www.icone-png.com/site-web/boite-mail"> Icones Boite mail <span>(27)</span></a></li><li><a href="https://www.icone-png.com/site-web/boutique"> Icones Boutique <span>(50)</span></a></li><li><a href="https://www.icone-png.com/site-web/bullet"> Icones Bullet <span>(24)</span></a></li><li><a href="https://www.icone-png.com/site-web/commentaire"> Icones Commentaire <span>(565)</span></a></li><li><a href="https://www.icone-png.com/site-web/contact"> Icones Contact <span>(156)</span></a></li></ul><ul><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- icone-png-menu-centre -->
<ins class="adsbygoogle"
     style="display:inline-block;width:180px;height:90px"
     data-ad-client="ca-pub-4576435841048824"
     data-ad-slot="8516377847"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script><li><a href="https://www.icone-png.com/site-web/copyright"> Icones Copyright <span>(24)</span></a></li><li><a href="https://www.icone-png.com/site-web/dossier"> Icones Dossier <span>(82)</span></a></li><li><a href="https://www.icone-png.com/site-web/download"> Icones Download <span>(527)</span></a></li><li><a href="https://www.icone-png.com/site-web/drapeau-pays"> Icones Drapeau pays <span>(258)</span></a></li><li><a href="https://www.icone-png.com/site-web/embed"> Icones Embed <span>(2)</span></a></li><li><a href="https://www.icone-png.com/site-web/export"> Icones Export <span>(35)</span></a></li><li><a href="https://www.icone-png.com/site-web/guillemet"> Icones Guillemet <span>(69)</span></a></li></ul><ul><li><a href="https://www.icone-png.com/site-web/link"> Icones Link <span>(142)</span></a></li><li><a href="https://www.icone-png.com/site-web/loading"> Icones Loading <span>(45)</span></a></li><li><a href="https://www.icone-png.com/site-web/new"> Icones New <span>(46)</span></a></li><li><a href="https://www.icone-png.com/site-web/newsletter"> Icones Newsletter <span>(1)</span></a></li><li><a href="https://www.icone-png.com/site-web/noel"> Icones Noel <span>(47)</span></a></li><li><a href="https://www.icone-png.com/site-web/organisation"> Icones Organisation <span>(8)</span></a></li><li><a href="https://www.icone-png.com/site-web/partenaire"> Icones Partenaire <span>(13)</span></a></li><li><a href="https://www.icone-png.com/site-web/precedent"> Icones Precedent <span>(64)</span></a></li><li><a href="https://www.icone-png.com/site-web/prise-note"> Icones Prise note <span>(326)</span></a></li><li><a href="https://www.icone-png.com/site-web/quitter"> Icones Quitter <span>(29)</span></a></li><li><a href="https://www.icone-png.com/site-web/rafraichir"> Icones Rafraichir <span>(302)</span></a></li></ul><ul><li><a href="https://www.icone-png.com/site-web/reduire"> Icones Reduire <span>(63)</span></a></li><li><a href="https://www.icone-png.com/site-web/rss"> Icones Rss <span>(372)</span></a></li><li><a href="https://www.icone-png.com/site-web/scheduled"> Icones Scheduled <span>(11)</span></a></li><li><a href="https://www.icone-png.com/site-web/search"> Icones Search <span>(334)</span></a></li><li><a href="https://www.icone-png.com/site-web/shuffle"> Icones Shuffle <span>(21)</span></a></li><li><a href="https://www.icone-png.com/site-web/sitemap"> Icones Sitemap <span>(42)</span></a></li><li><a href="https://www.icone-png.com/site-web/solde"> Icones Solde <span>(27)</span></a></li><li><a href="https://www.icone-png.com/site-web/star"> Icones Star <span>(261)</span></a></li><li><a href="https://www.icone-png.com/site-web/switch"> Icones Switch <span>(43)</span></a></li><li><a href="https://www.icone-png.com/site-web/upload"> Icones Upload <span>(285)</span></a></li><li><a href="https://www.icone-png.com/site-web/vendre"> Icones Vendre <span>(33)</span></a></li></ul>

    </div>
    <div class="contenu-onglet-top-search">
        <h2>top recherche</h2>
        <ul>
<li><a href="https://www.icone-png.com/png-pdf.php" title="icones png Pdf">Icone Pdf</a></li><li><a href="https://www.icone-png.com/png-google.php" title="icones png Google">Icone Google</a></li><li><a href="https://www.icone-png.com/musique" title="icones png Musique ">Icone Musique </a></li><li><a href="https://www.icone-png.com/webmaster/archives" title="icones png Archive">Icone Archive</a></li><li><a href="https://www.icone-png.com/webmaster/fleche" title="icones png Fleche">Icone Fleche</a></li><li><a href="https://www.icone-png.com/site-web/search" title="icones png Search">Icone Search</a></li><li><a href="https://www.icone-png.com/batiment/maison" title="icones png Maison ">Icone Maison </a></li><li><a href="https://www.icone-png.com/application/youtube" title="icones png Youtube">Icone Youtube</a></li>        </ul>
    </div>
  </div>
  
  <!-- fin premiere div --> 
  <!-- Seconde div -->
  
  <div class="contenu-onglet" id="contenuonglet2" style="display: none; ">
    <div class="contenu-onglet-moteur"><BR />
      <FORM Action="/search.php" Method=post class="form-search">
        <input type=text size=40 placeholder="Recherche" onfocus="javascript:initAutoComplete(document.getElementById('searchword'), '/ajax/search-general.php', '');" name=searchword id="searchword" autocomplete="off">
        <input type="image" src="/interface/icone-loupe.png" value="" name=""/>
      </form>
	  <BR /><BR />
    </div>
  </div>
  
  <!-- Fin Seconde div --> 
  <!-- Troisieme div -->
  
  <div class="contenu-onglet" id="contenuonglet3" style="display: none; ">
    <div class="contenu-onglet-moteur">
      <FORM Action="/search.php" Method=post class="form-search">
        <input type=text size=40 placeholder="Recherche" onfocus="javascript:initAutoComplete(document.getElementById('searchword2'), '/ajax/search-general.php', '');" name=searchword id="searchword2" autocomplete="off">
        <input type="image" src="/interface/icone-loupe.png" value="" name=""/><input type="hidden" name="addsearch" value="oui"/>
	  <BR />
<table border=0 cellspacing="4" cellpadding="4"><tr><td width="100">
        <p>Tailles :</p></td><td>
          <SELECT name="taille" class="form">
            <OPTION VALUE="0">Toutes les tailles</OPTION>
            <OPTION VALUE="50">Plus de 50 px</OPTION>
            <OPTION VALUE="150">Plus de 150 px</OPTION>
            <OPTION VALUE="250">Plus de 250 px</OPTION>
            <OPTION VALUE="500">Plus de 500 px</OPTION>
          </SELECT>
		  </td><td width="10">&nbsp;</td><td><p>Couleurs:</p></td></tr><tr><td>
        <p>Poids :</p></td><td>
          <SELECT name="poids" class="form">
            <OPTION VALUE="0">Tous les poids</OPTION>
            <OPTION VALUE="50">Plus de 50ko</OPTION>
            <OPTION VALUE="150">Plus de 150ko</OPTION>
            <OPTION VALUE="250">Plus de 250ko</OPTION>
            <OPTION VALUE="500">Plus de 500ko</OPTION>
          </SELECT>
		  </td><td width="10">&nbsp;</td><td>
        
        <table border="0" cellspacing="4" cellpadding="4">
          <tr>
            <td style="background-color: #000000; cursor: pointer;"><input type="checkbox" name="couleur0" class="form"></td>
            <td style="background-color: #787878; cursor: pointer;"><input type="checkbox" name="couleur1" class="form"></td>
            <td style="background-color: #FFFFFF; cursor: pointer;"><input type="checkbox" name="couleur2" class="form"></td>
            <td style="background-color: #FF0000; cursor: pointer;"><input type="checkbox" name="couleur3" class="form"></td>
            <td style="background-color: #ff7902; cursor: pointer;"><input type="checkbox" name="couleur4" class="form"></td>
            <td style="background-color: #fffc02; cursor: pointer;"><input type="checkbox" name="couleur5" class="form"></td>
            <td style="background-color: #17e212; cursor: pointer;"><input type="checkbox" name="couleur6" class="form"></td>
            <td style="background-color: #1256e2; cursor: pointer;"><input type="checkbox" name="couleur7" class="form"></td>
            <td style="background-color: #7e12e2; cursor: pointer;"><input type="checkbox" name="couleur8" class="form"></td>
            <td style="background-color: #fc33f0; cursor: pointer;"><input type="checkbox" name="couleur9" class="form"></td>
          </tr>
        </table>
		</td></tr></table><BR />
      </form>
    </div>
  </div>
  
  <!-- Fin Troisieme div --> 
</div>
<div class="contenu-onglet-bas">
  <div class="contenu-onglet-bas-pg">
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- icone-png-menu-haut -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:15px"
     data-ad-client="ca-pub-4576435841048824"
     data-ad-slot="1989610244"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
  </div>
</div>

<div class="contenu-centre">
  <div class="ariane"> <a href="https://www.icone-png.com"><strong>Icones</strong></a> > <a href="https://www.icone-png.com/site-web"><strong>Site web</strong></a> > <span>Commentaire</span></div>

      <DIV style="padding: 0px 2px 28px; width: 160px; height: 600px; float: left;"><!-- ICI largeur plus padding = 170 , hauteur plus padding = 610 --> 
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- icone-png-sky -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-4576435841048824"
     data-ad-slot="8392363845"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
      </DIV>


<DIV style="padding: 0px 2px 28px; width: 440px; height: 305px; float: right;">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- icone-png-centre-carre -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-4576435841048824"
     data-ad-slot="6341640648"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
      </DIV>
 <ul>

  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2021.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2021.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2021','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2021" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 11.4ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-grosse-resolution.php" onmouseover="img_swap('imgl2021','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2021" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme grosse-resolution.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2021.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2021.png" alt="message alt2 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43873.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43873.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43873','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43873" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 5.1ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-iphone-web.php" onmouseover="img_swap('imgl43873','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43873" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme iphone-web.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43873.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43873.png" alt="conversation b35" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1937.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1937.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1937','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1937" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 512 x 512<BR />Poids : 29.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-habbo.php" onmouseover="img_swap('imgl1937','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1937" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme habbo.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1937.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1937.png" alt="message 06 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43877.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43877.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43877','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43877" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 64 x 64<BR />Poids : 1.7ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-omnipage.php" onmouseover="img_swap('imgl43877','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43877" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme omnipage.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43877.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43877.png" alt="speech bubble left 4" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1883.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1883.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1883','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1883" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 96 x 96<BR />Poids : 3.4ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-free-rouge-buttons.php" onmouseover="img_swap('imgl1883','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1883" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme free-rouge-buttons.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1883.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1883.png" alt="message attention commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43818.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43818.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43818','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43818" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 256 x 256<BR />Poids : 34.8ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-colour-pencil.php" onmouseover="img_swap('imgl43818','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43818" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme colour-pencil.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43818.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43818.png" alt="blue 15" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1973.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1973.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1973','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1973" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 32 x 32<BR />Poids : 3.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-genre.php" onmouseover="img_swap('imgl1973','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1973" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme genre.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1973.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1973.png" alt="comment alt2 stroke 28 o55 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2025.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2025.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2025','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2025" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 6.5ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-handdrawn-web.php" onmouseover="img_swap('imgl2025','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2025" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme handdrawn-web.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2025.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2025.png" alt="comment red commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2015.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2015.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2015','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2015" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 6.9ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-grey-moonlight.php" onmouseover="img_swap('imgl2015','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2015" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme grey-moonlight.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2015.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2015.png" alt="comment commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1920.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1920.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1920','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1920" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 16 x 16<BR />Poids : 0.5ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-mini-site-internet.php" onmouseover="img_swap('imgl1920','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1920" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme mini-site-internet.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1920.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1920.png" alt="comments 7 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2016.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2016.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2016','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2016" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 80 x 80<BR />Poids : 3.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-user.php" onmouseover="img_swap('imgl2016','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2016" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme user.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2016.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2016.png" alt="interface message edit commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43798.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43798.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43798','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43798" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 64 x 64<BR />Poids : 1.5ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-omnipage.php" onmouseover="img_swap('imgl43798','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43798" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme omnipage.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43798.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43798.png" alt="speech bubble right" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1925.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1925.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1925','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1925" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 32 x 32<BR />Poids : 3.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-genre.php" onmouseover="img_swap('imgl1925','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1925" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme genre.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1925.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1925.png" alt="comment alt2 stroke 28 r52 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2142.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2142.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2142','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2142" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 64 x 64<BR />Poids : 0.4ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-avec-gimp.php" onmouseover="img_swap('imgl2142','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2142" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme avec-gimp.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2142.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2142.png" alt="comment v45 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1919.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1919.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1919','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1919" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 10ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-niveau.php" onmouseover="img_swap('imgl1919','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1919" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme niveau.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1919.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1919.png" alt="message commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2083.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2083.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2083','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2083" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 32 x 32<BR />Poids : 3ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-genre.php" onmouseover="img_swap('imgl2083','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2083" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme genre.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2083.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2083.png" alt="comment fill 28 v56 commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/23/22704.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/23/22704.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi22704','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi22704" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 5.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-iphone-web.php" onmouseover="img_swap('imgl22704','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl22704" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme iphone-web.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/23/22704.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/23/22704.png" alt="speech balloon v88" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43842.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43842.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43842','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43842" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 256 x 256<BR />Poids : 53.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-ete-collection.php" onmouseover="img_swap('imgl43842','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43842" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme ete-collection.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43842.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43842.png" alt="ichat" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2008.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2008.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2008','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2008" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 32 x 32<BR />Poids : 3.2ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-omega.php" onmouseover="img_swap('imgl2008','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2008" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme omega.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2008.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2008.png" alt="paper message commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1916.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1916.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1916','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1916" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 14.9ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-americaines.php" onmouseover="img_swap('imgl1916','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1916" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme americaines.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1916.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1916.png" alt="messages commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/2151.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/2151.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi2151','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi2151" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 32 x 32<BR />Poids : 0.5ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-graphic.php" onmouseover="img_swap('imgl2151','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl2151" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme graphic.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/2151.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/2151.png" alt="comments commentaire" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43891.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43891.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43891','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43891" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 48 x 48<BR />Poids : 3.9ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-flavour.php" onmouseover="img_swap('imgl43891','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43891" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme flavour.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43891.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43891.png" alt="speech bubble violet" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43875.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43875.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43875','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43875" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 512 x 512<BR />Poids : 83ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-social-icons.php" onmouseover="img_swap('imgl43875','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43875" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme social-icons.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43875.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43875.png" alt="indianpad" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43744.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43744.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43744','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43744" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 64 x 64<BR />Poids : 1.5ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-omnipage.php" onmouseover="img_swap('imgl43744','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43744" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme omnipage.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43744.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43744.png" alt="speech bubble left" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/44/43724.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/44/43724.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi43724','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi43724" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 48 x 48<BR />Poids : 5.9ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-noir-et-blanc.php" onmouseover="img_swap('imgl43724','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl43724" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme noir-et-blanc.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/44/43724.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/44/43724.png" alt="spechbubble" border="0"></a></div>
  </div></li>
  <li><div class="contenu-images">
    <ul>
      <li><a href="https://www.icone-png.com/png/2/1953.png" TARGET="_Blank">Png</a></li>
      <li><a href="https://www.icone-png.com/ico/2/1953.ico" TARGET="_Blank">Ico</a></li>
      <li class="icolink"><a onmouseover="img_swap('imgi1953','','/interface/icone-2-hover.png',1)" onmouseout="img_restor()"><img id="imgi1953" src="/interface/icone-2.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Informations';document.getElementById('pop_up_infobule_txt').innerHTML = 'Taille : 128 x 128<BR />Poids : 16.3ko <BR />Cat&eacute;gorie site-web commentaire';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li><li class="icolink"><a href="https://www.icone-png.com/theme-grosse-resolution.php" onmouseover="img_swap('imgl1953','','/interface/icone-1-hover.png',1)" onmouseout="img_restor()"><img id="imgl1953" src="/interface/icone-1.png" style="cursor: pointer;" onmouseover="document.getElementById('pop_up_infobule_titre').innerHTML = 'Recherche ciblée';document.getElementById('pop_up_infobule_txt').innerHTML = 'Cliquez ici afin d\'effectuer une recherche de toutes les icones du theme grosse-resolution.';popup_basic('pop_up_infobule', 'mousetrace', 20, -10);" onmouseout="popup_close('pop_up_infobule');"></a></li></ul>
    <div align="center" class="contenu-images-pos"> <a href="https://www.icone-png.com/png/2/1953.png" TARGET="_Blank"><img src="https://www.icone-png.com/png/2/1953.png" alt="message new commentaire" border="0"></a></div>
  </div></li>
 </ul>
<div class="pagination" style="padding: 0px 2px 28px; width: 1000px; height: 20px; float: left;"><BR />
 <p><a href=https://www.icone-png.com/site-web/commentaire>1</a> <a href=https://www.icone-png.com/site-web/commentaire/1.php>2</a> <a href=https://www.icone-png.com/site-web/commentaire/2.php>3</a> <a href=https://www.icone-png.com/site-web/commentaire/3.php class="actif">4</a> <a href=https://www.icone-png.com/site-web/commentaire/4.php>5</a> <a href=https://www.icone-png.com/site-web/commentaire/5.php>6</a> <a href=https://www.icone-png.com/site-web/commentaire/6.php>7</a> <a href=https://www.icone-png.com/site-web/commentaire/7.php>8</a> <a href=https://www.icone-png.com/site-web/commentaire/8.php>9</a> <a href=https://www.icone-png.com/site-web/commentaire/9.php>10</a> <a href=https://www.icone-png.com/site-web/commentaire/10.php>11</a> <a href=https://www.icone-png.com/site-web/commentaire/11.php>12</a> <a href=https://www.icone-png.com/site-web/commentaire/12.php>13</a> <a href=https://www.icone-png.com/site-web/commentaire/13.php>14</a> <a href=https://www.icone-png.com/site-web/commentaire/14.php>15</a> <a href=https://www.icone-png.com/site-web/commentaire/15.php>16</a> <a href=https://www.icone-png.com/site-web/commentaire/16.php>17</a> <a href=https://www.icone-png.com/site-web/commentaire/17.php>18</a> <a href=https://www.icone-png.com/site-web/commentaire/18.php>19</a> <a href=https://www.icone-png.com/site-web/commentaire/19.php>20</a> <a href=https://www.icone-png.com/site-web/commentaire/20.php>21</a> <a href=https://www.icone-png.com/site-web/commentaire/21.php>22</a></p> 
<BR />
</div></div>
<div class="footer-fond">
  <div class="footer-contenu">
    <div class="footer-vignette">
      <div class="footer-vignette-txt"> <A HREF="https://recom.hiwit.org" onClick="window.open('https://recom.hiwit.org/index.php?idsite=2416&zone=a','hiwit','toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=yes,width=520,height=370');return(false)" >Recomail</a>
        <p>Recommandez ce site a vos amis.</p><BR />
	<A HREF="https://news.hiwit.org" onClick="window.open('https://news.hiwit.org/index.php?idsite=5459&zone=a','hiwit','toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=yes,width=520,height=370');return(false)" >NewsLettre</a>
        <p>soyez informé des nouveautées.</p>
      </div>
      <div class="footer-vignette-img"><img  border="0" alt="description" src="/interface/icone-vignette-1.png"></div>
    </div>
    <div class="footer-vignette">
      <div class="footer-vignette-txt"> <a>Hotlink</a><BR />
        <p>Ajouter les icones sur votre site. Hotlink autorisé gratuitement</p>
      </div>
      <div class="footer-vignette-img"><img  border="0" alt="description" src="/interface/icone-vignette-2.png"></div>
    </div>
    <div class="footer-vignette">
      <div class="footer-vignette-txt"> <A HREF="https://form.hiwit.org" onClick="window.open('https://form.hiwit.org/index.php?idsite=4434&zone=a','hiwit','toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=yes,width=520,height=370');return(false)" >Copyright</a><BR />
        <p>Contactez-nous pour tous icones ayant un copyright.(joignez les url des images et icones concernées)</p>
      </div>
      <div class="footer-vignette-img"><A HREF="https://form.hiwit.org" onClick="window.open('https://form.hiwit.org/index.php?idsite=4434&zone=a','hiwit','toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=yes,width=520,height=370');return(false)" ><img  border="0" alt="description" src="/interface/icone-vignette-3.png"></a></div>
    </div>
    <div class="footer-partenaire">
      <h2>Partenaire</h2>
<ul><li><a href="https://www.icone-gif.com" title="Gifs Animés" target="_blank" >Icone Gif</a></li><li><a href="https://www.gif-maniac.com" title="Images animées fond transparent" target="_blank" >Gif Maniac</a></li><li><a href="https://www.mini-jeux.com" title="Mini Jeux gratuits" target="_blank" >Mini Jeux</a></li><li><a href="https://www.top-delire.com" title="Image drole video humour" target="_blank" >Top Delire</a></li></ul><ul><li><a href="https://www.actu-mobile.com" title="Actualité telephonie Mobile" target="_blank" >Actu Mobile</a></li><li><a href="https://www.full-wallpaper.com" title="Fonds d'ecran images wallpapers" target="_blank" >Full Wallpaper</a></li><li><a href="https://www.cuisine-du-monde.com" title="Recettes de cuisine gratuites" target="_blank" >Cuisine du Monde</a></li><li><a href="https://www.font-police.com" title="Polices de caracteres" target="_blank" >Font Police</a></li>      </ul>
    </div>
    <div class="footer-hipub">
      <center>
<table border=0><tr><td><IFRAME NAME=hipub SRC=https://hipub.hiwit.org/aff.cgi?zone=a&id=121413 width=468 height=60 MARGINWIDTH=0 MARGINHEIGHT=0 HSPACE=0 VSPACE=0 FRAMEBORDER=0 SCROLLING=no></IFRAME></td></tr>
<tr><td><center><a href=https://hipub.hiwit.org target=hilink>HiPub: Echange de bannières ciblées</A></td></tr></table> 
      </center>
    </div>
    <div class="footer-contact">
      <h2>Contactez-nous</h2>
      <p>Une remarque ? Vous souhaitez annoncer sur le site ou nous envoyer vos images et icones : <A HREF="https://form.hiwit.org" onClick="window.open('https://form.hiwit.org/index.php?idsite=4434&zone=a','hiwit','toolbar=no,location=no,directories=no,status=yes,scrollbars=yes,resizable=yes,copyhistory=yes,width=520,height=370');return(false)" >Formulaire de contact</a></p>
    </div>
  </div>
</div>
<div class="footer-copy">
<p>&copy; icone-png.com tous droits r&eacute;serv&eacute;s | <a href="https://www.hiwit.net/" title="Hebergement sur serveur hiwit.net" target="heberge">H&eacute;bergement Hiwit.net</a> </p>
</div>

<div id="pop_up_infobule" style="display: none;">

<table width="200" border="0" cellpadding="0" cellspacing="0" class="poptab2">
 <tr>
  <td class="poptab2-hg"></td>
  <td colspan="2" ><table width="100%" border="0" cellspacing="0" cellpadding="0">
   <tr>
    <td align="left" valign="bottom"  class="poptab2-h"><table border=0 cellspacing="0" cellpadding="0"><tr><td><img src="/interface/pop-icone-puce.png" border="0" /></td><td><span><b><div id="pop_up_infobule_titre"></div></b></span></td></tr></table></td>
    <td align="right" class="poptab2-hd"></td>
   </tr>
  </table></td>
 </tr>
 <tr>
  <td class="poptab2-g"></td>
  <td bgcolor="#f0f0f0"><p><div id="pop_up_infobule_txt"></div></p></td>
  <td class="poptab2-d"></td>
 </tr>
 <tr>
  <td class="poptab2-bg"></td>
  <td class="poptab2-b"></td>
  <td class="poptab2-bd"></td>
 </tr>
</table>

</div>

<script src="//cookie.aznet.fr/cookiechoices.js"></script><script>document.addEventListener('DOMContentLoaded', function(event) { cookieChoices.showCookieConsentBar('Ce site utilise des cookies pour vous offrir le meilleur service. En poursuivant votre navigation, vous acceptez l\'utilisation des cookies.','J\'accepte', 'En savoir plus', 'https://www.google.com/intl/fr/policies/privacy/partners/'); });</script>

</body>
</html>
