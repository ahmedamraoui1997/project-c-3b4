#include "reclam.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
enum
{
 DATE,
 TYPE,
 TEXT,
 REPD,
 COLUMNS
};
int a=0;
void repondre_reclam(char *rep, char *text)
{
a=1;
reclam r;
char test[100]="";
strcpy(r.repd,test);
strcpy(r.repd,rep);
FILE *f;
FILE *g;
f=fopen("reclam.bin","rb");
g=fopen("reclam.bin","ab");
int i=0;
while(!(feof(f)))
	{i++;
	fread(&r,1,sizeof(reclam),f);
	}
fclose(f);
f=fopen("reclam.bin","rb");
int j=0;
while (j<i)
{j++;
fread(&r,1,sizeof(reclam),f);
if (strcmp(r.text,text)==0)
{
g_print("hhh");
fwrite(&(r.repd),sizeof(reclam),1,g); 
}
}
fclose(g);
fclose(f); 
}

void ajouter (reclam *r)
{
FILE *f;
f=fopen("reclam.bin","ab"); //ouvrir un fichier en mode ajout
if(f!=NULL) //si le fichier est ouvert 
{
fwrite(r,sizeof(reclam),1,f); 
}
fclose(f); //fermeture du fichier
}


void afficher (GtkWidget *liste,reclam r)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f;
char repd[20]="";
store=gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Date de service", renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Type de service", renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Reclamation", renderer,"text",TEXT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new();
column= gtk_tree_view_column_new_with_attributes("Répondre", renderer,"text",REPD,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

store= gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
int i=0;
f=fopen("reclam.bin","rb"); 
while (!(feof(f)))
{
fread(&r,sizeof(reclam),1,f);
i++;
}
fclose(f);
f=fopen("reclam.bin","rb");
if (f!=NULL)
{int j=0;
while (j<i-1)
{
fread(&r,sizeof(reclam),1,f);
char r1[20];
char r2[20];
char r3[20];
char dt_date[20]="";
char vid[20]="";
sprintf(r1,"%d",r.date.jour);
strcat(dt_date,r1);
strcat(dt_date,"/");

sprintf(r2,"%d",r.date.mois);
strcat(dt_date,r2);
strcat(dt_date,"/");

sprintf(r3,"%d",r.date.annee);
strcat(dt_date,r3);
if(a==0)
{
strcpy(r.repd,vid);
}

gtk_list_store_append(store, &iter);
gtk_list_store_set(store,&iter,DATE,dt_date,TYPE,r.type_serv,TEXT,r.text,REPD,r.repd,-1);
j++;
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void dell_user(char *text)
{
reclam r;
FILE *old;
FILE *new=NULL;
/*****create a temporary file *****/
new=fopen("reclam_test.bin","wb");
fclose(new);
/******copy data from old to new *******/
old=fopen("reclam.bin","rb");
new=fopen("reclam_test.bin","ab");
/**************************/
int i=0;
while(!(feof(old)))
	{i++;
	fread(&r,1,sizeof(reclam),old);
	}
fclose(old);
old=fopen("reclam.bin","rb");
/******************************/
int j=0;
while(j<i-1)
	{j++;
	fread(&r,1,sizeof(reclam),old);
	if(strcmp(r.text,text))
		{	
		fwrite(&r,sizeof(reclam),1,new);
		}
	}
fclose(new);
fclose(old);
remove("reclam.bin");//nfas5ou il fichier li9dim
rename("reclam_test.bin","reclam.bin");//enronomiw il fichier ejdid b esm li9dim bech ye5ou blastou
/*****Na3mlo Actualiser lil liste **************/
}


