#ifndef RECLAM_H_
#define RECALM_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
typedef struct date_de_reclam
{
int jour;
int mois;
int annee;
}dt;

typedef struct reclamation
{
dt date;
char type_serv[50];
char text[20];
char repd[100];
}reclam;

void ajouter(reclam *r);
void repondre_reclam(char *rep, char *text);
void afficher (GtkWidget *liste,reclam r);
void dell_user(char *text);
#endif
