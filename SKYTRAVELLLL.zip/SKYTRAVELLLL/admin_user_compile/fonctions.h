#ifdef FONCTIONS_H_
#define FONCTIONS_H_

void ajouter(char login[], char password[]);
int verifier (char login[], char password[]);
#endif
