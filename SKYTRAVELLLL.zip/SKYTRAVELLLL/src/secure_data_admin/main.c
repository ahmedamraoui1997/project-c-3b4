#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "add.h"
#define ADMIN "ADMIN_ACCOUNT.bin"
#define CLIENT "CLIENT_ACCOUNT.bin"
int main()
{
    char login[20];
    char password[20];
    _Bool acces;

    printf("LOGIN:\n");
    fflush(stdin);
    gets(login);
    printf("PASSWORD:\n");
    fflush(stdin);
    gets(password);
    add_user(login, password, CLIENT);
	printf("CLIENT HAS BEEN ADDED SUCCESFULY!\n");
    return 0;
}
