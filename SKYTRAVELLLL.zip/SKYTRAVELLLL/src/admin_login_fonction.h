#ifdef ADMIN_LOGIN_FONCTION_H_
#define ADMIN_LOGIN_FONCTION_H_ 
#include <stdbool.h>
#include <gtk/gtk.h>


void add_user(char user_name[], char password[],char file_name[]);
bool verif_login(char login[], char password[], char file_name[]);
void afficher_agent_admin(GtkWidget *liste, char file_name[]);
bool verif_login_agent(char login[], char password[], char file_name[]);
bool verif_login_client(char login[], char password[], char file_name[]);
void add_client(char user_name[], char prenom[], char CIN[], char tel[], char email[],char password[],char con_password[] ,char file_name[]);


void Ajouter_agent(agent *x);
void Afficher_agent(GtkWidget *liste,agent x);
void dell_user(char *prenom);


#endif
