#ifdef HAVE_CONFIG_H
#  include <config.h>

#endif

#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "vol.h"
vol a;
char dt1[20];
char dt2[20];
void
on_appliquer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
vol v;
GtkWidget *dd=lookup_widget(GTK_WIDGET(button),"dd");
GtkWidget *aa=lookup_widget(GTK_WIDGET(button),"aa");
GtkWidget *jr=lookup_widget(GTK_WIDGET(button),"jr");
GtkWidget *ms=lookup_widget(GTK_WIDGET(button),"ms");
GtkWidget *an=lookup_widget(GTK_WIDGET(button),"an");
GtkWidget *jr1=lookup_widget(GTK_WIDGET(button),"jr1");
GtkWidget *ms1=lookup_widget(GTK_WIDGET(button),"ms1");
GtkWidget *an1=lookup_widget(GTK_WIDGET(button),"an1");
GtkWidget *d=lookup_widget(GTK_WIDGET(button),"d");
GtkWidget *classe=lookup_widget(GTK_WIDGET(button),"classe");
GtkWidget *prix=lookup_widget(GTK_WIDGET(button),"prix");

if((strcmp((gtk_entry_get_text(GTK_ENTRY(dd))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(aa))),"")==0)||(strcmp((gtk_entry_get_text(GTK_ENTRY(prix))),"")==0)||(strcmp(gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)),"")==0))
{ 
g_print("non");
GtkWidget *dialog1;
dialog1=create_dialog1() ;
gtk_widget_show(dialog1) ;

}
else{

strcpy(v.depart,gtk_entry_get_text(GTK_ENTRY(dd)));
strcpy(v.arrivee,gtk_entry_get_text(GTK_ENTRY(aa)));
v.aller.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr));
v.aller.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms));
v.aller.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an));

v.retour.jour= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jr1));
v.retour.mois= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(ms1));
v.retour.annee= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(an1));
v.duree= gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(d));
strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(prix)));

strcpy(v.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(classe)));


GtkWidget *dialog2;
dialog2=create_dialog2() ;
gtk_widget_show(dialog2) ;

ajouter(&v);
}
}


void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
gtk_main_quit();
}

void
on_ajout_clicked                       (GtkButton       *button,
                                        gpointer         user_data)
{

}
void
on_afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
vol v;
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");

GtkWidget *affich;
gtk_widget_destroy(window2);
window3=create_window3();
gtk_widget_show(window3);

affich=lookup_widget(window3,"affich");
afficher (affich,v);

}


void
on_retour_aj_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
gtk_widget_destroy(window3);
window2=create_window2();
gtk_widget_show(window2);

}


void
on_affich_row_activated                (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(a.depart,str_data);
}


void
on_supp_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
//GtkWidget *label=lookup_widget(GTK_WIDGET(button),"label16");
//gtk_label_set_text(GTK_LABEL(label),v.test);
dell_user((char *)a.depart);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
GtkWidget *affich;

affich=lookup_widget(window3,"affich");

afficher(affich,a);
gtk_widget_show(affich);
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
vol v;
dell_user((char *)a.depart);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window3=lookup_widget(GTK_WIDGET(button),"window3");
GtkWidget *affich;

affich=lookup_widget(window3,"affich");

afficher(affich,a);
gtk_widget_show(affich);


GtkWidget *window2=lookup_widget(GTK_WIDGET(button),"window2");

gtk_widget_destroy(window3);
window2=create_window2();
gtk_widget_show(window2);

}


void
on_closebutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog1=lookup_widget(GTK_WIDGET(button),("dialog1"));

gtk_widget_destroy(dialog1);
}


void
on_closebutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *dialog2=lookup_widget(GTK_WIDGET(button),("dialog2"));

gtk_widget_destroy(dialog2);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data1,*str_data2,*str_data3,*str_data4,*str_data6,*str_data7;
int *str_data5;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data1, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 1, &str_data2, -1);
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 2, &str_data3, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 3, &str_data4, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 4, &str_data5, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 5, &str_data6, -1);
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 6, &str_data7, -1);

  }
strcpy(a.depart,str_data1);
strcpy(a.arrivee,str_data2);
strcpy(dt1,str_data3);
strcpy(dt2,str_data4);
a.duree=str_data5;
strcpy(a.classe,str_data6);
strcpy(a.prix,str_data7);

}
void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
dell_user_res((char *)a.depart);
/*****Na3mlo Actualiser lil liste **************/
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *treeview2;

treeview2=lookup_widget(window4,"treeview2");

afficher(treeview2,a);
gtk_widget_show(treeview2);
}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
vol v;
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
gtk_widget_destroy(window4);
window1=create_window1();
gtk_widget_show(window1);
GtkWidget *treeview1;
treeview1=lookup_widget(window1,"treeview1");
afficher (treeview1,v);

}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter   iter;
  if (gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store), &iter, path))
  {
  gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter, 0, &str_data, -1);
  }
strcpy(a.depart,str_data);
}


void
on_afficher1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
vol v;
GtkWidget *window1=lookup_widget(GTK_WIDGET(button),"window1");
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");

GtkWidget *treeview2;
gtk_widget_destroy(window1);
window4=create_window4();
gtk_widget_show(window4);

treeview2=lookup_widget(window4,"treeview2");
afficher_resv (treeview2,a,dt1,dt2);
}


void
on_appliquer1_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4=lookup_widget(GTK_WIDGET(button),"window4");
GtkWidget *nbp=lookup_widget(GTK_WIDGET(button),"entry1");
GtkWidget *treeview2;
nbp=lookup_widget(GTK_WIDGET(button),"entry1");
strcpy(a.nb,gtk_entry_get_text(GTK_ENTRY(nbp)));
ajouter_resv (&a);

}

