#include <gtk/gtk.h>


void
on_quitter_activate                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_affich_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter2_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_window2_destroy                     (GtkObject       *object,
                                        gpointer         user_data);

void
on_quitter_reclam_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajout_reclam_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_Reclam_activate_default             (GtkWindow       *window,
                                        gpointer         user_data);

void
on_Reclam_activate_focus               (GtkWindow       *window,
                                        gpointer         user_data);

void
on_quitte_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_admin_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_reclam_admin_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supp_admin_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_reclam_admin_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_supp_admin_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_agent_clicked                       (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifer_agent_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_quitter_agent_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_valider_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_reclam_agent_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affich_row_activated                (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_modifer_agent_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_repondre_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok_repondre_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_repondre_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifer_client_clicked              (GtkButton       *button,
                                        gpointer         user_data);
